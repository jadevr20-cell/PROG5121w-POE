/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.messageapp;

/**
 *
 * @author GHOST
 */
public class MessageManager {
    // Arrays to store message data
    static String[] sentMessages; // Stores all sent messages
    static String[] disregardedMessages; // Stores disregarded messages
    static String[] storedMessages; // Stores stored messages
    static String[] messageHashes; // Stores hashes of messages
    static String[] messageIDs; // Stores message IDs
    static String[] messageContents; // Stores message contents
    
    // Initialize arrays with a specified size, e.g., 100
    static int maxMessages = 100;
    
    static {
        sentMessages = new String[maxMessages];
        disregardedMessages = new String[maxMessages];
        storedMessages = new String[maxMessages];
        messageHashes = new String[maxMessages];
        messageIDs = new String[maxMessages];
        messageContents = new String[maxMessages];
    }
}

import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

public class MessageManager {
    // Existing arrays...

    public static void loadMessagesFromJSON(String filename) {
        try {
            String content = new String(Files.readAllBytes(Paths.get(filename)));
            JSONArray jsonArray = new JSONArray(content);
            for (int i = 0; i < jsonArray.length() && i < maxMessages; i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                // Example keys: recipient, message, flag, hash, id
                messageIDs[i] = obj.getString("id");
                messageContents[i] = obj.getString("message");
                // For simplicity, store sender/recipient as part of the message string or separately as needed
                sentMessages[i] = "Recipient: " + obj.getString("recipient") + ", Message: " + obj.getString("message");
                // Add logic to populate other arrays based on flag/status
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

