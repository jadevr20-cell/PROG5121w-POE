/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.messageapp;

/**
 *
 * @author GHOST
 */
public class MessageApp {

   static void showStoredMessagesMenu() {
    Scanner scanner = new Scanner(System.in);
    boolean back = false;
    while (!back) {
        System.out.println("\nStored Messages Menu:");
        System.out.println("a. Display sender and recipient of all stored messages");
        System.out.println("b. Display the longest stored message");
        System.out.println("c. Search for a message ID");
        System.out.println("d. Search for messages for a particular recipient");
        System.out.println("e. Delete a message using message hash");
        System.out.println("f. Display full details of all stored messages");
        System.out.println("g. Back to main menu");
        System.out.print("Select an option: ");
        String option = scanner.nextLine();

        switch (option.toLowerCase()) {
            case "a":
                displaySenderRecipient();
                break;
            case "b":
                displayLongestMessage();
                break;
            case "c":
                searchMessageByID();
                break;
            case "d":
                searchMessagesByRecipient();
                break;
            case "e":
                deleteMessageByHash();
                break;
            case "f":
                displayFullDetails();
                break;
            case "g":
                back = true;
                break;
        }
    }
}
   
static void displaySenderRecipient() {
    for (int i = 0; i < maxMessages; i++) {
        if (messageIDs[i] != null) {
            System.out.println("Recipient: " + messageContents[i]); // Adjust based on data
        }
    }
}
