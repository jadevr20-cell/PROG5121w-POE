/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author GHOST
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Load JSON data
        MessageManager.loadMessagesFromJSON("messages.json");
        
        // Show menu
        while (true) {
            System.out.println("Main Menu:");
            System.out.println("1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message");
            System.out.println("4. Stored Messages");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = new Scanner(System.in).nextInt();
            switch (choice) {
                case 4:
                    showStoredMessagesMenu();
                    break;
                case 5:
                    System.exit(0);
                // Add other cases as needed
            }
        }
    }

    static void showStoredMessagesMenu() {
        // Implement submenu for stored messages
    }
}

public static void populateTestData() {
    // Message 1
    messageIDs[0] = "ID1";
    messageContents[0] = "Did you get the cake?";
    sentMessages[0] = "Recipient: +27834557896, Message: Did you get the cake?";
    messageHashes[0] = "hash1";
    // ... Continue for other messages
}