/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author GHOST
 */
public class MessageManagerTest {
    @Test
    public MessageManagerTest() {
   essageManager.populateTestData();
        assertEquals("Did you get the cake?", MessageManager.messageContents[0]);
        // Add more assertions for other data
    }
    // Add tests for longest message, search, delete, report, etc.
}
